package com.skatespotter.dto;

public class RegisterRequest {

}
