package com.skatespotter.controller;

import com.skatespotter.model.SkateSpot;
import com.skatespotter.service.SkateSpotService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.skatespotter.dto.SkateSpotDTO;


import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/spots")
public class SkateSpotController {

    private final SkateSpotService skateSpotService;

    public SkateSpotController(SkateSpotService skateSpotService) {
        this.skateSpotService = skateSpotService;
    }

    @GetMapping
    public List<SkateSpotDTO> getAllSpots() {
        return skateSpotService.findAll().stream()
            .map(SkateSpotDTO::new)
            .toList();
    }

    // 🔹 GET: Buscar spot por ID
    @GetMapping("/{id}")
    public ResponseEntity<SkateSpotDTO> getSpotById(@PathVariable Long id) {
        return skateSpotService.findById(id)
            .map(spot -> ResponseEntity.ok(new SkateSpotDTO(spot)))
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 🔹 POST: Criar novo spot (username é passado no body TEMPORARIAMENTE)
    @PostMapping
    public ResponseEntity<SkateSpot> createSpot(@RequestBody SkateSpotRequest request) {
    	SkateSpot created = skateSpotService.save(request.getSpot(), request.getUsername());
        return ResponseEntity.ok(created);
    }

    // 🔹 DELETE: Excluir spot se for o dono
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteSpot(@PathVariable Long id, @RequestParam String username) {
        try {
            skateSpotService.delete(id, username);
            return ResponseEntity.ok("Spot deleted");
        } catch (SecurityException e) {
            return ResponseEntity.status(403).body("Permission denied");
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Perguntar para o chat como criar o PUT 
    
    // 🔹 GET: Listar spots criados por um usuário
    @GetMapping("/by-user/{username}")
    public ResponseEntity<List<SkateSpot>> getSpotsByUser(@PathVariable String username) {
        return ResponseEntity.ok(skateSpotService.findByUser(username));
    }

    // 🔹 Classe interna de request (usada temporariamente para passar o username)
    public static class SkateSpotRequest {
        private SkateSpot spot;
        private String username;

        public SkateSpot getSpot() {
            return spot;
        }

        public void setSpot(SkateSpot spot) {
            this.spot = spot;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }
    }
}
