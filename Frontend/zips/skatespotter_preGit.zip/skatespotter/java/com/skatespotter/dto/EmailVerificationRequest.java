package com.skatespotter.dto;

public class EmailVerificationRequest {

}
